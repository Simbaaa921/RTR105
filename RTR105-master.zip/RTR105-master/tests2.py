n = 0
while n > 0:
    print('Lather')
    print('Rinse')
print('Dry off!')

