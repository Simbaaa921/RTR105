#mans_mainigais = input("Cienījamais lietotāj, lūdzu, ievadi skaitli:")
mans_mainigais = raw_input("Cienījamais lietotāj, lūdzu, tekstu:")
#x = mans_mainigais * mans_mainigais


# http://www.cplusplus.com/reference/cstdio/printf/
print("Lietotāj, Tu esi ievadījis tekstu: %s"%(mans_mainigais))
#print("Kā arī tagad atmiņā ir arī x = %s"%(x))



'''
print("Lietotāj, Tu esi ievadījis vērtību: %10.4f"%(mans_mainigais))
print("Kā arī tagad atmiņā ir arī x = %15.3f"%(x))
'''
'''
print("Lietotāj, Tu esi ievadījis vērtību: %d"%(mans_mainigais))
print("Kā arī tagad atmiņā ir arī x = %d"%(x))
'''
