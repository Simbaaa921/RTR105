# RTR105
Darmacības kursa elektroniska klade
uname - ļauj apskatit lietotaja nosaukumu
Ctrl+Alt+T - ļauj atvert Shell valodas logu
Ctrl+L - ekrana attirīšana
pwd - ļauj uzzināt mūsu vietu
who - ļauj uzzināt kas es esmu
man + jebkura komanda - ļauj uzzināt informāciju par šo komandu
uname -a - informācija par lietotāju
burts>Tab - ļauj dabut sarakstus
history - komandas vēsture
ls -a - ļauj uzzināt informāciju par failiem
q - ļauj izziet no "man" komandas
mkdir- ļauj uztaisit jaunu mapi
echo- ļauj parvietot datus uz citiem failiem
cd- ļauj ienakt uz directoriju
